# Climber's Paradise!

Youtube Video URL: https://youtu.be/I2yfgnd-p1k

# Background

This project makes frequent use of Mountain Project, (https://www.mountainproject.com/) a website with user uploads of climbing routes across the United States. Users are able to add specific climbs with various information such as difficulty, height, and location. Through these user uploads Mountain Project now contains information about over 278,000 climbs. Mountain project allows the users to filter climbs based on state, difficulty, etc. Then, it allows a user to export a csv with all of the climbs that match the designated parameters.

Climbs are separated primarily into two types. Rock. And Boulder. "Rock" is typically 20 feet or higher up, while "boulder is typically 20 feet and under. This means that boulders don't utilize ropes as protection, while rock climbs will. Boulders will just have pads placed in the fall zone. Rock climbs are separated into three types which are sport, trad, and ice. Sport climbs use pre-drilled bolts in the wall to provide protection. Trad(itional) climbs place removeable gear as they go, typically into cracks in the rock. Ice climbs use picks in ice and screw into ice as they go for protection.

# Setup

This project is a Python-based website that utilizes Flask in order to run. As such, in order to run the projects only a few steps are required.
* Upload the .zip of project files into VSCODE.
* Unzip the folder
* Use cd/project to change your working directory to the folder with all of the project files in it.
* Your terminal should now show "project/. $ "
* Now type "flask run" into the terminal and open up the corresponding link. This will take you to the website.

# Use

The homepage will be https://www.climbing.com/ embedded into the website. This allows for a climber to see at a glance what is going on in the climbing world while they are just logging a training session or searching for a climb. You may navigate this and click on any article to go read that article on that website. On the top of the screen you will see the three primary functions of this website.
* Route Finder
* Training Logger
* Gear Shop

# Route Finder

The route finder is arguably the most useful of the tabs. It allows the user to utilize the same criteria for filtering the climbs as Mountain Project does; however, each climb on Mountain Project also has a user-provided description that has further details on the climb. This route finder tab allows the user to include a text filter that will only include climbs whose description includes that word or phrase. Leave this empty if you don't want to filter based on the text in the description.

If you're using the search based on text, this can take a good bit of time. When you're doing this you want to make sure that your other parameters return a small list of climbs or boulders. A good way to do this is often to just do the very hard climbs like the range V10-V10 or 5.14b or 5.14c and up. The number of climbs available varies a lot by state as well.

After indicating the state you'd like to search, the type of climb, the difficulty range(left value is the minimum grade and the right value is the maximum grade), and an optional text filter, you can click submit and the website will return to you a list of all climbs that match the criteria you set. It'll spit out a table with the name, a link to the mountain project page, it's average rating, it's difficulty along with some other data.

# Training Logger

The training logger is relatively straight forward. It allows you to list a type of training, a result, and the date. It will sort first by 'type' and then by 'date'.

This is the only part of the app that requires you to be logged in. This way data for multiple users can be privately stored. If you click on training logger when you are not logged in, you will automatically be redirected to the login page. You may also log in or register on by navigating to those pages by clicking on them in the top right. When you are logged in, you will consistently see a "Welcome {{name}}" displayed in the top right with the ability to log out.

# Gear Shop

This allows you to search for any bits of gear that you might need whether it be quickdraws, a harness, or a rope. It will search Black Diamond's website and return to you the images and prices of the top 5 search results for the search that you submit. All the user must do is type in what gear they'd like to look for and hit submit.

# Profile

This is an additional tidbit where if you click on your name in the top right of the webpage after logging in then you will see when you created your account and how many training sessions you have logged.