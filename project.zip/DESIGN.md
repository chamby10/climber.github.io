# Design

I wanted to create a way for rock climbers to be able to have everything they need in one space. The most prominent site out there that accomplishes this task is Mountain Project. It has a large user-generated database of rock climbs as well as forums. This site is a large inspiration for the project, and my website sends numerous requests to Mountain Project.

I decided to create a python-based website using flask primarily because it's what seemed most efficient. I knew that it would be a large amount of data, and I thought that being able to use Python to manipulate the data that I was downloading from Mountain Project would make things a lot easier.

I also knew that I would be querying a lot of other websites, and the requests library that we were utilizing for the Finance pset seemed to be apt for the requesting that I wanted to do.

# Homepage

For the homepage I just embedded the news page of another climbing website that posts many articles. I did this using requests.get and beautiful soup's html parser. Then I just passed all of the html to the html file with the "|safe" added in so that it does in fact read it as html code.

# Route Finder

The user indicates what criteria they want the returned rock climbs to match, and this request is sent to Mountain Project and the data is downloaded as a CSV. The user input is achieved through html input tags and html select tags. Then the request.form.get is used to include this user input in the request sent to Mountain Project.

Various dictionaries were created because Mountain Project often had unique ID's rather than just a string. For instance each state had a unique id, and I made a dictionary that would allow for easy conversion of the user input into a unique id. This was the case for difficulties as well. Mountain project had values that corresponded to various difficulties, and I needed to create a dictionary in order to be able to request Mountain Project with the right values.

Then this data retrieved from Mountain Project is passed to the html to be represented as a table. If the user includes a text filter, a slower, arduous process begins. I used BeautifulSoup to parse through the html associated with each climb's link. By searching for the class "fr-view" I was able to get the text of the description. Then all that's needed is to check if the text provided by the user is in the description from the website. If it is, then that climb is returned in table. If it's not then that climb is removed from the table.

# Training Logger

This is a much simpler tab where there are just three inputs on the html page and when the user hits submit, these inputs are inserted into a SQL table that holds the training data for all users. I chose SQL because it seemed like the easiest way to store data that needs to be readily accessed. Also, if there were a larger number of users, it would allow for quick queries of the training data. A value for username is included with each entry in order to only a show a user their own training logs. For this reason, if your session["user_id"] has no value (you're not signed in) you will automatically be prompted to sign in in order to use the training logger.

# Gear Shop

The gear shop took me a while to figure out how to do, along with the "keyword search" in the route finder. Again I had a form in the html file that asks the user for input. Then this user input is passed in a requests.get(blackdiamond.com) with the search added on to the end of the url. I used beautiful soup's html parser to look through the html of that specific url and find the top 5 products that the website returns. Then by using the classes as search attributes in beautiful soup, I was able to find the sources of the images, which I downloaded to the static folder and then passed the location of them to html using url_for. I was also able to find the prices of the first 5 products by searching by the class as well. I was able to figure out the class that was used for each bit by using "Inspect" and looking through the HTML of the website.

# Profile

If a user clicks on their name in the top right corner while they're signed in it will take them to profile.html where the website will query the SQL table to figure out when the account was created and how many trainings you have logged.