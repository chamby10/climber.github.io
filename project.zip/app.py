#import necessary packages
import requests
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
import csv
import datetime
from cs50 import SQL
from werkzeug.security import check_password_hash, generate_password_hash
from bs4 import *
import os
import numpy as np

#start application

# A lot of this framework is taken from the C$50 Finance pset. The app.config and the app.route parts along with the layout.html file.

app = Flask(__name__)

app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Setup our SQL database
db = SQL("sqlite:///routes.db")
# Make sure that it has all the tables that we want it to have
db.execute("CREATE TABLE IF NOT EXISTS users (username TEXT NOT NULL, passwordhash TEXT NOT NULL, time DATETIME NOT NULL)")
db.execute("CREATE TABLE IF NOT EXISTS training (username TEXT NOT NULL,type TEXT NOT NULL, result TEXT NOT NULL , date DATE NOT NULL)")
db.execute("CREATE TABLE IF NOT EXISTS ticklist (username TEXT NOT NULL, route TEXT NOT NULL, location TEXT NOT NULL, type TEXT NOT NULL, rating TEXT NOT NULL)")

# Unfortunately, manually create dictionaries with unique id's that Mountain Project uses.
statedict = dict({"Alabama":"105905173", "Alaska":"105909311", "Arizona":"105708962", "Arkansas":"105901027", "California":"105708959", "Colorado":"105708956", "Connecticut":"105806977", "Delaware":"106861605", "Florida":"111721391", "Georgia":"105897947","Hawaii":"106316122", "Idaho":"105708958", "Illinois":"105911816", "Indiana":"112389571", "Iowa":"106092653", "Kansas":"107235316","Kentucky":"105868674","Louisiana":"116720343", "Maine":"105948977", "Maryland":"106029417", "Massachusetts":"105908062", "Michigan":"106113246", "Minnesota":"105812481", "Mississippi":"108307056", "Missouri":"105899020", "Montana":"105907492", "Nebraska":"116096758", "Nevada":"105708961", "New Hampshire":"105872225", "New Jersey":"106374428", "New Mexico":"105708964", "New York":"105800424", "North Carolina":"105873282", "North Dakota":"106598130", "Ohio":"105994953", "Oklahoma":"105854466", "Oregon":"105708965", "Pennsylvania":"105913279", "Rhode Island":"106842810", "South Carolina":"107638915", "South Dakota":"105708963", "Tennessee":"105887760", "Texas":"105835804", "Utah":"105708957", "Vermont":"105891603", "Virginia":"105852400", "Washington":"105708966", "West Virginia":"105855459", "Wisconsin":"105708968", "Wyoming":"105708960"})
diffdict = dict({"5.2":"1200","5.3":"1300","5.4":"1400","5.5":"1500","5.6":"1600","5.7":"1800","5.8":"2000","5.9":"2300","5.10a":"2600","5.10b":"2700","5.10c":"3100","5.10d":"3300","5.11a":"4600","5.11b":"4800","5.11c":"5100","5.11d":"5300","5.12a":"6600","5.12b":"6700","5.12c":"7100","5.12d":"7200","5.13a":"8600","5.13b":"8700","5.13c":"9200","5.13d":"9500","5.14a":"10500","5.14b":"10900","5.14c":"11200","5.14d":"11500","5.15a":"11600","5.15b":"11900","5.15c":"12100","5.15d":"12400"})

#Set up our homepage
@app.route("/",methods = ["GET","POST"])
def index():
    # Don't require that a user is signed in, but, if they are, we put a welcome message in the top right.
    if session.get("user_id") is not None:
        name = session.get("user_id")
    else:
        name = 0

    # embed climbing news in the homepage
    url = requests.get("https://www.climbing.com/news/")
    soup = BeautifulSoup(url.content, 'html.parser')
    # pass the name of the user(if there is one) and the html code of climbing.com's news
    return render_template("index.html",name = name,x=soup)

# Set up our Route Finder
@app.route("/route",methods = ["GET","POST"])
def route():
    # Same for all pages, check to see if user is logged in and display name if so.
    if session.get("user_id") is not None:
        name = session.get("user_id")
    else:
        name = 0

    # check to see request type. If it is post, that means the user has submitted what they want to be searched, and we download based on those parameters
    if request.method == "POST":
        # Request data from Mountain Project based on user input
        if request.form.get("rocktype") == "rock":
            if request.form.get("rocktype1") == "trad":
                url = requests.get("https://www.mountainproject.com/route-finder-export?type={}&selectedIds={}&diffMinrock={}&diffMinboulder=20000&diffMinaid=00000&diffMinice=00000&diffMinmixed=00000&diffMaxrock={}&diffMaxboulder=21700&is_trad_climb=1&is_sport_climb=0&is_top_rope=0&stars=0&pitches=0&sort1=area&sort2=rating".format(request.form.get("rocktype"),statedict.get(request.form.get("state")),diffdict.get(request.form.get("ydsgrademin")),diffdict.get(request.form.get("ydsgrademax"))))
            if request.form.get("rocktype1") == "sport":
                url = requests.get("https://www.mountainproject.com/route-finder-export?type={}&selectedIds={}&diffMinrock={}&diffMinboulder=20000&diffMinaid=00000&diffMinice=00000&diffMinmixed=00000&diffMaxrock={}&diffMaxboulder=21700&is_trad_climb=0&is_sport_climb=1&is_top_rope=0&stars=0&pitches=0&sort1=area&sort2=rating".format(request.form.get("rocktype"),statedict.get(request.form.get("state")),diffdict.get(request.form.get("ydsgrademin")),diffdict.get(request.form.get("ydsgrademax"))))
            if request.form.get("rocktype1") == "toprope":
                url = requests.get("https://www.mountainproject.com/route-finder-export?type={}&selectedIds={}&diffMinrock={}&diffMinboulder=20000&diffMinaid=00000&diffMinice=00000&diffMinmixed=00000&diffMaxrock={}&diffMaxboulder=21700&is_trad_climb=0&is_sport_climb=0&is_top_rope=1&stars=0&pitches=0&sort1=area&sort2=rating".format(request.form.get("rocktype"),statedict.get(request.form.get("state")),diffdict.get(request.form.get("ydsgrademin")),diffdict.get(request.form.get("ydsgrademax"))))
        else:
            url = requests.get("https://www.mountainproject.com/route-finder-export?type={}&selectedIds={}&diffMinrock=0000&diffMinboulder={}&diffMinaid=00000&diffMinice=00000&diffMinmixed=00000&diffMaxrock=200000&diffMaxboulder={}&is_trad_climb=1&is_sport_climb=1&is_top_rope=1&stars=0&pitches=0&sort1=area&sort2=rating".format(request.form.get("rocktype"),statedict.get(request.form.get("state")),str(20000+ int(request.form.get("bgrademin")[1:])*100),str(20000+ int(request.form.get("bgrademax")[1:])*100)))
        # Get the content from the url that we got.
        content = url.content
        x = content
        # write it to a csv
        newcsv = open("./downloaded.csv","wb")
        newcsv.write(content)
        newcsv.close()
        # create a new list to store our data in. a little funky for sure but it works.
        x = []
        with open("downloaded.csv","r") as file:
            csvreader = csv.reader(file)
            for row in csvreader:
                x.append(row)
        # get lengths for the for loops
        nrow = len(x)
        ncol = len(x[0])
        desc = []
        for i in range(nrow-1): # nrow - 1 because no header
            newurl = requests.get(x[i+1][2]) # i+1 because of the header
            soup = BeautifulSoup(newurl.text,"html.parser") #initialize our search of the html with beautiful soup
            content = soup.find(attrs={"class": "fr-view"}) # this is the class for the climb descriptions
            content = content.contents # get just the contents of the description
            desc.append(content) # add it to the list
        # store the text input into the text box
        filterword = request.form.get("filter")
        # first row is header so we always want that
        boollist = np.array([True])
        for i in range(nrow-1): #nrow - 1 because no header
            if str(filterword) in str(desc[i]): # if keyword is in the climb's description
                boollist = np.append(boollist,True)
            else:
                boollist = np.append(boollist,False)
        print(boollist)
        x = np.array(x)
        x = x[boollist]
        # remove first object from list
        ones = np.ones(len(boollist),dtype = bool)
        ones[0] = 0
        boollist = boollist[ones]
        # make it an array and remove first item
        desc = np.array(desc)
        desc = desc[boollist]
        # get lengths to pass to the html for the for loops
        nrow = len(x)
        ncol = len(x[0])
        return render_template("routed.html",x=x,nrow=nrow,ncol = ncol,name = name,desc = desc)
    else:
        # Let's allow the user to select any state
        states = ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"]
        #ydsgrades =
        return render_template("route.html",states=states,name = name)

# Set up training logger
@app.route("/train",methods = ["GET","POST"])
def train():
    if session.get("user_id") is None:
        return redirect("/login")
    name = session.get("user_id")

    if request.method == "POST": # Update if user has submitted a training session
        if not request.form.get("type") or not request.form.get("result") or not request.form.get("date"):
            return render_template("error.html",message = "put something for all entries") # throw error
        # add training session
        db.execute("INSERT INTO training VALUES (?,?,?,?)",session["user_id"],request.form.get("type"),request.form.get("result"),request.form.get("date"))
        # Then display the current list of training sessions
        rows = db.execute("SELECT * FROM training WHERE (username = ?) ORDER BY type,date",session["user_id"])
        # get lengths for the html for loops
        nrow = len(rows)
        ncol = len(rows[0])
        return render_template("train.html",x = rows, nrow = nrow, ncol = ncol,name = name)
    else:
        # Get the training sessions
        rows = db.execute("SELECT * FROM training WHERE (username = ?) ORDER BY type,date",session["user_id"])
        nrow = len(rows)
        ncol = 0
        # do this because the indexing doesn't work if you have no training sessions
        if nrow > 0:
            ncol = len(rows[0])

        return render_template("train.html",x = rows, nrow = nrow, ncol = ncol,name = name)

# Set up login
@app.route("/login", methods=["GET", "POST"])
def login():
    session.clear()
    if request.method == "POST": # if they submitted the form we'll check it
        # have to enter stuff
        if not request.form.get("user"):
            return render_template("error.html",message = "input a username")
        if not request.form.get("pw"):
            return render_template("error.html",message = "input a password")
        # see if there's a user with that username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("user"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["passwordhash"], request.form.get("pw")):
            return render_template("error.html", message = "incorrect username or password")

        # Remember which user has logged in
        session["user_id"] = rows[0]["username"]
        return redirect("/")
    else: # if it's GET then we just show the login screen. Name = 0 because there's no username.
        return render_template("login.html",name = 0)

#Set up register
@app.route("/register", methods=["GET", "POST"])
def register():
    session.clear()
    if request.method == "POST": # check if user has tried to register
        # make sure there are inputs for everything
        if not request.form.get("user"):
            return render_template("error.html",message = "input a username")
        if not request.form.get("pw"):
            return render_template("error.html",message = "input a password")
        # Select rows with that username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("user"))
        # make sure there isn't already that username
        if len(rows) != 0 :
            return render_template("error.html", message = "username taken")
        # create username in SQL
        db.execute("INSERT INTO users VALUES (?,?,?)",request.form.get("user"),generate_password_hash(request.form.get("pw")),datetime.datetime.now())
        # log the user in
        session["user_id"] = request.form.get("user")
        return redirect("/")
    else:
        # if it's GET then we just need to show the screen. Name = 0 because user not signed in
        return render_template("register.html",name = 0)


@app.route("/shop",methods = ["GET","POST"])
def shop():
    # check for username
    if session.get("user_id") is not None:
        name = session.get("user_id")
    else:
        name = 0
    if request.method == "POST":
        # if post then user has searched something
        # request the black diamond url plus the search that the user input
        url = requests.get("https://www.blackdiamondequipment.com/en_US/search/{}/".format(request.form.get("query")))
        soup = BeautifulSoup(url.text,"html.parser") # Get the html text
        content = soup.find_all(attrs={"class": "low-regular-price"}) # Get the price
        images = soup.find_all(attrs={"class":"product-thumb-image"}) # Get the image
        x = []
        for i in range(5): # just get the first 5 entries
            x.append("image" + str(i) + ".jpg")
            img_data = requests.get(images[i].img['data-src']).content # get the content (the image) at each source included in the html
            with open('static/image' + str(i) + '.jpg', 'wb') as handler: # create numbered images
                handler.write(img_data) # write the image to the file.
        content = content[:5] # take the first 5 prices
        for i in range(5):
            content[i] = content[i].contents # make them just the prices
        # Feed all of this to be displayed
        return render_template("shop.html",content = content,name = name,images = x)
    return render_template("shop.html",name = name, content = "")

# Set up the profile where user can see when account was created and how many training sessions they've logged
@app.route("/profile",methods = ["GET","POST"])
def profile():
    if session.get("user_id") is not None: # if they're logged in
        name = session["user_id"]
        # get the time that user was created
        rows = db.execute("SELECT time FROM users WHERE username = ?",session["user_id"])
        rows = rows[0]['time']
        # get the number of training sessions
        training = db.execute("SELECT * FROM training WHERE username = ?",session["user_id"])
        sesh = len(training)
        # pass data to html
        return render_template("profile.html",name = name,date = rows, sesh = sesh)
    return redirect("/login")